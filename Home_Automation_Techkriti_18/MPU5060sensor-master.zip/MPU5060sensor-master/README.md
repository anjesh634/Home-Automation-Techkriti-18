# MPU6050sensor
This repository contains all the necessary codes/library functions/files required for the operation of an MPU6050 sensor.
Download all the (.ZIP) files onto your system.
Follow the instructions as provided in my blog (https://www.hackster.io/Aritro)
for any kind of queries ,kindly mail me : aritro.mukherjee18@gmail.com
